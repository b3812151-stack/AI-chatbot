# AI Chatbot Using NLP

Simple AI chatbot project for internship submission.

Author: Bhumika Sharma
