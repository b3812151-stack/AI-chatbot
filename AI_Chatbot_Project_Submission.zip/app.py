print("AI Chatbot Using NLP")
while True:
    q=input("You: ")
    if q.lower()=="bye":
        print("Bot: Goodbye!")
        break
    print("Bot: Thanks for your question.")